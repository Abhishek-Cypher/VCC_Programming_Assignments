All the write-up for all the 3 parts have been included in a single pdf file titled "WRITEUP_22M0761.pdf"
