#define _GNU_SOURCE
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <iostream>
using namespace std;

// A SIMPLE CLONE PROGRAM

#define STACK_SIZE (1024 * 1024)
static char child_stack[STACK_SIZE];

static int child_fn(void *arg) {
  // CHILD HAS A NEW PID NAMESPACE
  printf("PID of child process = %ld\n", (long)getpid());
  return 0;
}

int main() {

  pid_t child_pid = clone(child_fn, child_stack+STACK_SIZE, CLONE_NEWPID | SIGCHLD, NULL);
  printf("PID of parent process = %ld\n", (long)getpid());

  waitpid(child_pid, NULL, 0);  // WAIT FOR CHILD TO FINISH

  return 0;
}
