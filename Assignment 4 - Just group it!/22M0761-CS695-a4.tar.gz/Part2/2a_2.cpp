#define _GNU_SOURCE
#include <fcntl.h>
#include <sched.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#define errExit(msg)    do { perror(msg); exit(EXIT_FAILURE); \
                        } while (0)

int main(int argc, char *argv[])
{
    int fd;

    if (argc < 3) {
        fprintf(stderr, "USAGE: %s /proc/PID/ns/FILE cmd [arg...]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
	
	// getting the file descriptor of the namespace
    fd = open(argv[1], O_RDONLY);  
	
	// using setns
    setns(fd, 0);
	
	// executing a program in the new namespace
    execvp(argv[2], &argv[2]);   
    
    return 0;
}

