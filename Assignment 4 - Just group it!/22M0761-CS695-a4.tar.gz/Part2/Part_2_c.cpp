#define _GNU_SOURCE
#include <fcntl.h>
#include <sched.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

// ERROR HANDLING FUNCTION
#define errExit(msg)    do { perror(msg); exit(EXIT_FAILURE); \
                        } while (0)

int main(int argc, char *argv[])
{
    int fd, pid;
    char path[512];
    
    // ACCEPT A TOTAL OF 4 ARGUMENTS
    if (argc < 4) {
        fprintf(stderr, "USAGE: %s PID ns_file namespace cmd [arg...]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
	
	// accepting the pid as an argument
    pid = atoi(argv[1]);            
    snprintf(path, sizeof(path), "/proc/%d/ns/%s", pid, argv[2]);

    fd = open(path, O_RDONLY);      // namespace fd
    if (fd == -1)
        errExit("open");

    if (setns(fd, 0) == -1)         // setns command accepting fd
        errExit("setns");

    execvp(argv[3], &argv[3]);      // execute the program/command in the new namespace
    errExit("execvp");

    return 0;
}
