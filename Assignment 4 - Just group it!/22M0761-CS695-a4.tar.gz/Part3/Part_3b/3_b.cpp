#define _GNU_SOURCE
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <iostream>
#include <iostream>
#include <ctime>
using namespace std;

#define STACK_SIZE (1024 * 1024)
static char child_stack[STACK_SIZE];

static int child_fn(void *arg) {

	clock_t start = clock();	// EXECUTION TIME NOTED AFTER CHILD CREATED

  	std::cout << "Child process is running in directory (using getcwd): " << getcwd(nullptr, 0) << std::endl;
  	printf("PID of child process = %ld\n", (long)getpid());

    for (int i = 0; i < 4; i++) {
            pid_t child_pid = fork();

            if (child_pid == -1) {
                std::cerr << "Error: fork() failed" << std::endl;
                return 1;
            } else if (child_pid == 0) {
                printf("PID of child process = %ld\n", (long)getpid());
                
                // CHILD DOING SOME WORK
                double y=0;
                for(double x=0; x<1000000000; x++)
                {
                	y=y/2;
                	y=y*2;
                }
                
                return 0;
            }
        }

        int status;
        for (int i = 0; i < 4; i++) {
            if (wait(&status) == -1) {
                std::cerr << "Error: wait() failed" << std::endl;
                return 1;
            }
        }
        clock_t stop = clock();
  
  double duration = (double)(stop - start) / CLOCKS_PER_SEC; 
    
   cout << "Total Execution time: " << duration * 1000 << " milliseconds" << endl;
  return 0;
}

int main() {
 	printf("PID of parent process = %ld\n", (long)getpid());
 	cout<<"Press any key after adding this program to a CGROUP to continue execution and child process creation\n";	
 	getchar();
 	
 	
    
 	
  pid_t child_pid = clone(child_fn, child_stack+STACK_SIZE, CLONE_NEWPID | SIGCHLD, NULL);
  // printf("PID of parent process = %ld\n", (long)getpid());

  waitpid(child_pid, NULL, 0);  // WAIT FOR CHILD TO FINISH
  
  
    

  return 0;
}
