#!/bin/bash

# NEW ROOT DIRECTORY LOCATION (FOR MY SYSTEM)
ROOT_DIR=/home/abhishek_ubuntu/Documents/Part3
mkdir -p $ROOT_DIR/{bin,lib,lib64}

# COPY NECESSARY DEPENDENCIES
cp -v /bin/{bash,touch,ls,g++,g++-11,aarch64-linux-gnu-g++,aarch64-linux-gnu-g++-11} $ROOT_DIR/bin

ldd /bin/bash

list="$(ldd /bin/bash | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

list="$(ldd /bin/touch | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

list="$(ldd /bin/ls | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

list="$(ldd /bin/g++ | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

list="$(ldd /bin/g++-11 | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

list="$(ldd /bin/aarch64-linux-gnu-g++ | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

list="$(ldd /bin/aarch64-linux-gnu-g++-11 | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

list="$(ldd 3_b | egrep -o '/lib.*\.[0-9]')"
echo $list
for i in $list; do cp -v --parents "$i" "${ROOT_DIR}"; done

sudo chroot $ROOT_DIR /bin/bash

