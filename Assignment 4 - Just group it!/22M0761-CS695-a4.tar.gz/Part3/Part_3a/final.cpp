#define _GNU_SOURCE
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <iostream>
using namespace std;

#define STACK_SIZE (1024 * 1024)
static char child_stack[STACK_SIZE];

static int child_fn(void *arg) {
  	std::cout << "Child process is running in directory (using getcwd): " << getcwd(nullptr, 0) << std::endl;
  	printf("PID of child process = %ld\n", (long)getpid());

    for (int i = 0; i < 4; i++) {
            pid_t child_pid = fork();

            if (child_pid == -1) {
                std::cerr << "Error: fork() failed" << std::endl;
                return 1;
            } else if (child_pid == 0) {
                printf("PID of child process = %ld\n", (long)getpid());
                return 0;
            }
        }

        int status;
        for (int i = 0; i < 4; i++) {
            if (wait(&status) == -1) {
                std::cerr << "Error: wait() failed" << std::endl;
                return 1;
            }
        }
  return 0;
}

int main() {
 
  pid_t child_pid = clone(child_fn, child_stack+STACK_SIZE, CLONE_NEWPID | SIGCHLD, NULL);
  printf("PID of parent process = %ld\n", (long)getpid());

  waitpid(child_pid, NULL, 0);  // WAIT FOR CHILD TO FINISH

  return 0;
}
