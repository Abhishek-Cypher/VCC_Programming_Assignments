#include <stdio.h>
#include <pthread.h>
#include <stdint.h>

#define NUM_THREADS 200

void *calculate(void *arg) {
    intptr_t n = (intptr_t)arg;
    int i, result = 1;

    for(i = 1; i <= n; i++) {
        result *= i;
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int i;

    printf("STARTING STRESS TEST WITH 200 THREADS\n");

    for(i = 0; i < NUM_THREADS; i++) {
        intptr_t arg = (intptr_t)(i + 10000000);
        pthread_create(&threads[i], NULL, calculate, (void *)arg);
    }

    for(i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("STRESS TEST COMPLETE !\n");

    return 0;
}
