#!/bin/bash

# CPU INTENSIVE PROCESS 2
pkill cpu_200_2;
g++ cpu_200_2.cpp -o cpu_200_2;

# CGROUP 2
if ! [ -d /sys/fs/cgroup/cpu/group2 ]; then
    if ! sudo mkdir /sys/fs/cgroup/cpu/group2; then
        exit 1
    fi
fi

QUOTA_VAR=("250000", "500000", "1000000", "2000000")
PERIOD_VAR=("250000", "500000", "1000000", "2000000")
SHARES_VAR=("128", "256", "512", "1024", "2048")
# for quo in "${QUOTA_VAR[@]}"
# do
    # FIXED VALUES
    shr=4096
    sudo sh -c "echo 1000000 > /sys/fs/cgroup/cpu/group2/cpu.cfs_period_us"     #period
    sudo sh -c "echo 4096 > /sys/fs/cgroup/cpu/group2/cpu.shares"   #shares
    sudo sh -c "echo 4000000 > /sys/fs/cgroup/cpu/group2/cpu.cfs_quota_us"   #quota

    start_time=`date +%s%N`  # START OF EXECUTION TIME

    echo "RUNNING cpu_200_2..."
    ./cpu_200_2 &
    cpid=$!
    echo "cpu_200_2 IS NOW RUNNING WITH PID: $cpid"
    echo

    echo "ADDING PROCESS TO CGROUP..."
    if ! echo $cpid > /sys/fs/cgroup/cpu/group2/cgroup.procs; then
        echo "ERROR: FAILED TO ADD PROCESS TO CGROUP."
        exit 1
    fi
    echo "PROCESS ADDED TO CGROUP."
    echo    

    echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    echo FOR cpu.shares = `expr $shr` WITH cpu.cfs_quota_us = 1000000 and cpu.cfs_period_us = 1000000 
    echo
    echo "cpu.stat BEFORE PROCESS RUNS:"
    cat /sys/fs/cgroup/cpu/group2/cpu.stat
    echo

    tail --pid=$cpid -f /dev/null # WAIT FOR cpu_200_2 TO END
    end_time=`date +%s%N`

    echo
    echo Execution Time is = `expr $end_time - $start_time` nanoseconds
    echo 

    echo "cpu.stat AFTER PROCESS ENDS:"
    cat /sys/fs/cgroup/cpu/group2/cpu.stat
    echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    echo
   
