// Note - To Load this module, use command "sudo insmod lkm5.ko process_id=<a>" Where, <a> = PID input by user

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/sched/mm.h>
#include <linux/moduleparam.h>
#include <linux/pgtable.h>
#include <linux/mm.h>

MODULE_DESCRIPTION("Part 5 Kernel Module");
MODULE_AUTHOR("22M0761");
MODULE_LICENSE("GPL");

// TAKING USER ARGUMENT FOR "PID"
static long process_id = 1;

module_param(process_id, long, 0660);

static int part5_load(void)
{	
    struct task_struct *t;
	struct mm_struct *m;
	struct vm_area_struct *v;
	
	long long vas = 0;
	long long pas = 0;
	
	int flag = 0;
    for_each_process(t)
    {	
    	if( t->pid == process_id )
    	{
    		flag = 1;	//	PROCESS WITH ENTERED PID EXISTS !
    		break;
    	}
    } 
    if(flag==0)
    {
    	printk("ERROR, No Task for the entered PID found !\n");
    	return 0;
    }
    m = t -> mm;
    
    if(!m)
    {
    	printk("ERROR, No Memory Descriptor found !\n");
    	return 0;
    }
    
    v = m->mmap;
    while(v)
    {
    	vas += (v->vm_end) - (v->vm_start);
    	v = v -> vm_next;
    }
    vas = vas / 1024;
    
    pas = get_mm_rss(m) * PAGE_SIZE;
    pas = pas / 1024; 
    
    printk("Size of allocated Virtual Address Space for given process is = %lld KiloBytes... Size of allocated Physical Address Space for given process is = %lld KiloBytes \n", vas, pas);
    return 0;
    
}

static void part5_unload(void)
{
    printk("Successfully Unloaded the Module !\n");
}

module_init(part5_load);
module_exit(part5_unload);


