#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/sched/mm.h>
#include <linux/sched/task.h>

MODULE_DESCRIPTION("Part 3 Kernel Module");
MODULE_AUTHOR("22M0761");
MODULE_LICENSE("GPL");

static int part3_load(void)
{
    struct task_struct *t;
	int process_id = 1;	// Since we want to find task with PID 1
	
    for_each_process(t)
    {	
    	if( t->pid == process_id )
    	{
    		printk("The `Kernel stack pointer` of the Task with PID 1 (using task_struct->stack) is = %p\n", t -> stack);
    		//printk("The `Kernel stack pointer` of the Task with PID 1 (using task_struct->thread.sp) is = %p\n", t->thread.sp);
    		break;
    	}
    }  
     
    return 0;
}

static void part3_unload(void)
{
    printk("Successfully Unloaded the Module !\n");
}

module_init(part3_load);
module_exit(part3_unload);


