#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    int* array = (int*) malloc(1000000 * sizeof(int));
    int i;
    
    printf("MALLOC DONE, NOW SLEEPING \n");
    sleep(30);
    printf("AWAKE step1\n");

    for (i = 0; i < 1000000; i++) {
        array[i] = i;
    }
	
	printf("VALUES ASSIGNED, NOW SLEEPING \n");
	sleep(30);
	printf("AWAKE step2\n ");
	
    for (i = 0; i < 1000000; i += 100) {
    	usleep(1900);
        printf("%d ", array[i]);
    }
    printf("AWAKE step3\n ");

    free(array);
    return 0;
}

