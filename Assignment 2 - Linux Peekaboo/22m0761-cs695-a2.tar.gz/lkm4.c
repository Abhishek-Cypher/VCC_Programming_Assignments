/* To Load this module, use command "sudo insmod lkm4.ko process_id=<a> virt_addr=<b>"
Where, <a> = PID input by user, <b> = Virtual Address input by user
*/

/* WARNING: PLEASE ENTER THE VIRTUAL ADDRESS AS A DECIMAL OFFSET AND NOT AS A HEXADECIMAL VALUE i.e. NO 0xffff94f9c001 Format, only ffff94f9c001 Format */

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/sched/mm.h>
#include <linux/moduleparam.h>
#include <linux/pgtable.h>

MODULE_DESCRIPTION("Part 4 Kernel Module");
MODULE_AUTHOR("22M0761");
MODULE_LICENSE("GPL");

// TAKING USER ARGUMENTS FOR "PID" AND "VIRTUAL ADDRESS"
static long process_id = 1;
static long virt_addr = 0;

module_param(process_id, long, 0660);
module_param(virt_addr, long, 0660);

static int part4_load(void)
{	
    struct task_struct *t;
	struct mm_struct *m;
	// 5 LEVELS OF THE LINUX PAGE TABLE
	pgd_t *pg_gd;	p4d_t *pg_4d;	pud_t *pg_ud;	pmd_t *pg_md;	pte_t *pg_te;
	
	int flag = 0;
    for_each_process(t)
    {	
    	if( t->pid == process_id )
    	{
    		flag = 1;	//	PROCESS WITH ENTERED PID EXISTS !
    		break;
    	}
    } 
    if(flag==0)
    {
    	printk("ERROR, No Task for the entered PID found !\n");
    	return 0;
    }
    
    m = t -> mm;	// ACCESSING mm_struct for given PROCESS
    if(!m)
    {
    	printk("ERROR, No Memory Descriptor found !\n");
    	return 0;
    }
    
    // WALKING THE PAGE TABLE
    pg_gd = pgd_offset(m, virt_addr);
    if(pgd_present(*pg_gd))
    {	
    	pg_4d = p4d_offset(pg_gd, virt_addr);
    	if(p4d_present(*pg_4d))
    	{
			pg_ud = pud_offset(pg_4d, virt_addr);
			if(pud_present(*pg_ud))
			{	
				pg_md = pmd_offset(pg_ud, virt_addr);
				if(pmd_present(*pg_md))
				{	
					pg_te = pte_offset_map(pg_md, virt_addr);
					if(pte_present(*pg_te))
					{
						unsigned long phy_addr = (pte_pfn(*pg_te) * PAGE_SIZE) + (virt_addr % PAGE_SIZE);
						printk("Entered PID = %ld\n", process_id);
						printk("Entered Virtual Address = %ld\n", virt_addr);
						printk("Corresponding Physical Address = %lu\n", phy_addr);
						return 0;
					}
				}
			}
		}
    }
    // ANY LEVEL OF PAGE TABLE WALK FAILED / MAPPING NOT PRESENT
    printk("ERROR, Could not find the Corresponding PHYSICAL ADDRESS for the entered VIRTUAL ADDRESS"); 
    return 0;
}

static void part4_unload(void)
{
    printk("Successfully Unloaded the Module !\n");
}

module_init(part4_load);
module_exit(part4_unload);


