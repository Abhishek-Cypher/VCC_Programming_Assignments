#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/sched/mm.h>

MODULE_DESCRIPTION("Part 2 Kernel Module");
MODULE_AUTHOR("22M0761");
MODULE_LICENSE("GPL");

static int part2_load(void)
{
    struct mm_struct *m;
    struct task_struct *t;
	pid_t process_id;
	long long cur_heap_memory = 0, max_heap_memory = 0;
	
    for_each_process(t)
    {	
    	m = get_task_mm(t);
    	if(m)
    	{
			cur_heap_memory = m->brk - m->start_brk;
			//cur_heap_memory = m-> total_vm;
		    if (cur_heap_memory > max_heap_memory)
		    {
		        max_heap_memory = cur_heap_memory;
		        process_id = t -> pid;
		    }
		    mmput(m);
        }
    }   
    
    printk("The process with `PID = %d` and `HEAP Memory usage = %lld Bytes' has the Largest `in use` Heap Memory !\n", process_id, max_heap_memory);
    
    return 0;
}

static void part2_unload(void)
{
    printk("Successfully Unloaded the Module !\n");
}

module_init(part2_load);
module_exit(part2_unload);


