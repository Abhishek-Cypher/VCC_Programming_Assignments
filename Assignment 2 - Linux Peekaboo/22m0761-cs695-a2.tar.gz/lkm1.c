#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/sched.h>

MODULE_DESCRIPTION("Part 1 Kernel Module");
MODULE_AUTHOR("22M0761");
MODULE_LICENSE("GPL");

static int part1_load(void)
{
    struct task_struct *task;

    printk("PID and NAMES of `running or runnable state` Processes = \n");

    for_each_process(task)
    {
        if (task->__state == TASK_RUNNING)
        {
            printk("%d %s\n", task->pid, task->comm);
        }
    }   
    return 0;
}

static void part1_unload(void)
{
    printk("Successfully Unloaded the Module !\n");
}

module_init(part1_load);
module_exit(part1_unload);


