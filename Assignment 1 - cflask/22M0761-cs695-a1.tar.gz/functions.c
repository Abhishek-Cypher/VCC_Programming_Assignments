#include<string.h>
#include<stdio.h>
#include<stdlib.h>

char s[10000] = "Hello";
char ans[1000000];

char* function(char *num)
{
	char *s = "Hello world";
	return s;
}
char* square(char *num)
{	
	if(strlen(num)==0)
		return "1";
	int num1 = atoi(num);
	int res = num1 * num1;
	snprintf(ans, 10, "%d", res);
	return ans;
}
char* cube(char *num)
{	
	if(strlen(num)==0)
		return "1";
	int num1 = atoi(num);
	int res = num1 * num1 * num1;
	snprintf(ans, 10, "%d", res);
	return ans;
}
char* helloworld(char *str)
{	
	strcpy(s,"Hello");
	if(strlen(str)==0)
		return s;
	else
		{
			strcat(s,",");
			strcat(s,str);
		}
	return s;
}
char* pingpong(char* str)
{	
	if(strlen(str)==0)
		return "PingPong";
	return str;
}
char* arithmeticprime(char *num)
{	
	int num1 = atoi(num);
	for(int i=2;i<=(num1/2)+1;i++)
	{
		if(num1%i == 0)
			return "False";
	}
	return "True";
}
char* arithmeticfibonacci(char *k)
{	
	if(strlen(k)==0)
		return "1";
	int k1 = atoi(k);
	int a=0,b=1,c;
	if(k1<=0)
	    return "0";
	 if(k1==1)
	    return "1";
	 for(int i=2;i<k1;i++)
	 {
	     c=a+b;
	     a=b;
	     b=c;
	 }
	 snprintf(ans, 10, "%d", b);
	 return ans;
}

