#ifndef FUNCTIONS_H
#define FUNCTIONS_H

char* function(char*);
char* square(char*);
char* cube(char*);
char* helloworld(char*);
char* pingpong(char*);
char* arithmeticprime(char*);
char* arithmeticfibonacci(char*);

char* urls[7] = {
"/",
"/square",
"/cube",
"/helloworld",
"/pingpong",
"/arithmetic/prime",
"/arithmetic/fibonacci"
};

#endif
