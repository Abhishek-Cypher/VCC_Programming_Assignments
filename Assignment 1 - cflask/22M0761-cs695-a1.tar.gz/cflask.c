// 22M0761 - ABHISHEK DIXIT - MTech CSE TA 1st Year

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "civetweb.h"
#include "functionslist.h"
#include "functions.h"

static int request_handler(struct mg_connection *conn)
{
    const struct mg_request_info *request_info = mg_get_request_info(conn);
    char content[1000] = "";
    int content_length = 0;
    int flag = 0;
    
    /*// CHECKING OUT ALL THE FIELDS INSIDE "mg_request_info" struct
    printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n\n",request_info->request_method,request_info->request_uri,request_info->local_uri,
    request_info->uri,request_info->http_version,request_info->query_string,request_info->remote_user,request_info->remote_addr);
    */
    
    strcpy(content, "404 ERROR : FUNCTION NOT FOUND !!!");
	content_length = strlen(content) + 1;
    
    // request_info->request_uri -- HAS FUNCTION NAME
    // request_info->query_string -- HAS ARGUMENTS
    
    char *argument_value = "";	// DEFAULT ARGUMENT VALUE, HANDLED IN functions.c
    
    if(request_info->query_string)	// WILL ONLY RUN IF THERE IS A QUERY STRING i.e. "?num=3" EXISTS
    {	
		char *argument_location = strchr(request_info->query_string, '=');
		if(argument_location)	// WILL ONLY RUN IF THERE IS SOME VALUE PROVIDED AS ARGUMENT AFTER "=" SIGN, ACTUALLY IF "=" EXISTS
		{
			argument_value = argument_location + 1;
		}
		else
		{
			argument_value = "";
		}
    }
    
    for(int i = 0; i < sizeof(urls)/sizeof(urls[0]); i++)	// SEARCH FOR THE FUNCTION MENTIONED IN "request_uri" IN MAPPING 
    {
    	if(strcmp(urls[i], request_info->request_uri) == 0)		// REQUESTED FUNCTION EXISTS
    	{
    		strcpy(content, functions_array[i](argument_value));	// CALLING THE FUNCTION FROM "ARRAY OF FUNCTION POINTERS" AND STORING RESULT
    		content_length = strlen(content) + 1;
    		flag = 1;
			break;
    	}
    }
    
    if(flag == 1)	// FUNCTION FOUND
    {
    	mg_printf(conn,
				  "HTTP/1.1 200 OK\r\n"
				  "Content-Type: text/plain\r\n"
				  "Content-Length: %d\r\n"       
				  "\r\n"
				  "%s",
				  content_length, content);
	}
	else	// FUNCTION MATCH NOT FOUND, FLAG = 0 STILL
	{
		mg_printf(conn,
				  "HTTP/1.1 404 No Content\r\n"
				  "Content-Type: text/plain\r\n"
				  "Content-Length: %d\r\n"        
				  "\r\n"
				  "%s",
				  content_length, content);
	}   
    
    return 1;
}


int main(int argc, char *argv[])
{	

	if (argc < 2)
  	{
    	fprintf(stderr, "ERROR, 'port number' and/or 'number of server threads' INPUT NOT PROVIDED !!!\n");
    	fprintf(stderr, "For executing, USE : ./clask <port number> <number of server threads> \n");
    	exit(1);
  	}
  	
	const char* port_no = argv[1];
	const char* server_threads_no = argv[2];

	// SERVER STARTS LISTENING AT INPUTTED "port_no" USING "libhttp" listen function
	struct mg_context *ctx;
    struct mg_callbacks callbacks;
    
    const char *options[] = {"listening_ports", port_no,
    						 "num_threads", server_threads_no,
    						 "decode_url", "yes",
    						 NULL};
    						 
	memset(&callbacks, 0, sizeof(callbacks));
    callbacks.begin_request = request_handler;
    ctx = mg_start(&callbacks, NULL, options);
    
    if(ctx==NULL)
    {
    	printf("ERROR STARTING SERVER!");
    }
    
    getchar();
	
    mg_stop(ctx);
	
	return 0;
}

