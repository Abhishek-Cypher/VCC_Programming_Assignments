#include "functions.h"

char* (*functions_array[7]) (char*) = 
{
	function,
	square,
	cube,
	helloworld,
	pingpong,
	arithmeticprime,
	arithmeticfibonacci
};
