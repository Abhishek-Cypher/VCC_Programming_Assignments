CS695 - 22M0761 - ABHISHEK DIXIT - Assignment 1

Reporting of experiment:- 

( Note:- For all the 3 functions/HTTP endpoints tested, all of the points are same since the aim, execution details and expectations are identical. The observed difference in throughput and mean response time is negligible and differences have been mentioned below. )

i) aim/purpose of the experiment - 
The aim of this experiment is to make a simple server "cflask.c" using "libHTTP" library, while also learning about function mapping to HTTP requests. Also, to perform a load testing on the designed server using "apache bench" and plotting the results of the load test into graphs to analyse the functioning of the server.

ii) setup and execution details, metrics and independent parameter - 
Setup and execution details have been mentioned step-wise at the end of this "README.md" file. The metrics used for load testing are also mentioned in the ".data" files which store the output of the apache bench load tests.

iii) hypothesis/expectation - 
For the functioning of the server, I expect the server to function normally and deliver results for the functions that have been defined in the "function.c" file as per the assignment Part 5(a). For the functions that are not been defined there, an error message with code 404 is expected to be generated. In case of missing arguments or redundant arguments, proper handling of such requests has been done as specified in the assignment to ensure server does not crash abruptly. 
For load testing, it is expected that linearly increasing the "number of concurrent requests"(c) through apache bench will lead to a linear increase in the throughput, until it reaches a "threshold value" after which the throughput will plateau and will not increase further even on increasing "c value". Upon reaching this "threshold value", the "Mean time per request" is also expected to linearly increase.
Increasing the number of threads is expected to increase the throughput for same "c values" until it stops affecting it.

iv) observations from the data/plots - 
(a) As expected, In case of "1 server thread", throughput value plateaued at around 9500-10000 requests/sec for all the three fucntions/HTTP endpoints tested. Response time increased linearly after the throughput achieved plateau. (CPU utilization ~ 50%) (There is a minor difference in values in the 3 cases which can be observed in the .data files of each of the functions as well as the graphs). 
(b) In case of "2 server threads", throughput value plateaued at around 26000 requests/sec for all the three fucntions/HTTP endpoints tested. Response time increased linearly after the throughput achieved plateau. (CPU utilization ~ 70-75%)
(c) In case of "3 server threads", throughput value plateaued at around 33000 requests/sec for all the three fucntions/HTTP endpoints tested. Response time increased linearly after the throughput achieved plateau. (CPU utilization ~ 96-99%)
(d) In case of "4 server threads", throughput value plateaued at around 33000 requests/sec for all the three fucntions/HTTP endpoints tested. Response time increased linearly after the throughput achieved plateau. i.e Same as previous one. So, stopped experiment there. (CPU utilization ~ 96-99%)
(e) Increasing the threadpool size of the server also caused a gradual decrease in the mean response time.

v) explanation of behavior and inferences - 
(a) As observed above, The CPU utilization was the bottleneck in the above case and the reason for throughput plateue, as it reached ~99% during the load tests.
(b) As there was no .html file being read from the local device's storage, this implies there was no I/O bottleneck during the load test.
(c) Also, no memory bottleneck was observed during the load test. This was also verified by observing the "Top" command's metrics for Memory usage.
(d) Since 3 server threads were enough to make almost 100% utilization of the CPU which explains/implies number of threads is not a bottleneck.
(e) The linear increase in Mean response time results from the fact that the incoming requests get queued and since the queue size is limited, the number of requests queued reaches a threshold and later the response time taken is responding to HTTP requests becomes linear.
(f) Also, i inferred that, since there is almost no change in throughput in case of functions taking input argument vs functions not taking inout arguments. This explains that argument processing and result generation does not take much time if the time complexity of the function is not much. This stems from the fact that current CPUs can operate at a very high frequency.
(g) Increasing the threadpool size of the server also caused a gradual decrease in the mean response time, because some threads had some idle time initially at threadpool value 1 and 2 (since CPU utilization not 100%), but when T=3 was done, the server was running at capacity and hence response time decreased slightly.

Note:- Relevant comments have been written with the code to explain some of the functionalities.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Setup and execution details / Running instructions - 

Step 1) Make sure the submission folder "22M0761-cs695-a1" is in the folder location "libhttp-1.8/examples/", as the Makefile is written accordingly.

Step 2) Open a terminal tab at the folder "22M0761-cs695-a1".

Step 3) Run "make" to run the Makefile. (Modified the Makefile given in the example "hello")

Step 4) Run the command "./cflask <port number> <number of threads>" for running the cflask server. For load testing, I have made the server to run on a single CPU core. Command used - "taskset -c 0 ./cflask 4040 <threads_value>" 
Note:- Thread value is varied between 1,2,3 for all the 3 functions/endpoints.

Step 5) In another terminal tab, run the command "taskset -c 1-4 ab -n 100000 -c <concurrent_requests_value> http://localhost:4040/<function_name>"
Note:- concurrent_requests_value is varied from 1 to 8.
Note:- function_name was varied between "/helloworld", "arithmetic/prime?num=8", "square?num=5"

Step 6) The results are redirected to append to a ".data" file. 
Command used "taskset -c 1-4 ab -n 100000 -c <concurrent_requests_value> http://localhost:4040/<function_name> >> file1.data"

Step 7) The "Requests per second" and "Time per request (mean)" values are extracted from the data files of each of the 3 functions and graphs were plotted with seperate curves for different size of threadpool for the server. Hence, a total of 3 graphs and 3 .data files are created.

Note:- Tried larger values for "server threads" (T=5,10,50) and "concurrent requests" (10,100,1000) values but there was not much information gain, since throughput value did not increase further after reaching a plateau value in all the 3 cases (at T=3/T=4).

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Note:- To increase the readability of the apache bench output, a folder "functionwise_data" with function-wise and number of server threads wise data files (t_1,t_2,t_3) is present.
